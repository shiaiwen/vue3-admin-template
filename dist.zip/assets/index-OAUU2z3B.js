import{_ as e,o,f as t,k as c}from"./index-iq3_YIvd.js";const n={},s=c("h1",null,"一级路由404",-1),_=[s];function r(a,d){return o(),t("div",null,_)}const f=e(n,[["render",r]]);export{f as default};
