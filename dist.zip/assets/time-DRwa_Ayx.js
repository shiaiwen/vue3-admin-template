const t=()=>{let e="";const s=new Date().getHours();return s<=9?e="早上":s<=12?e="上午":s<=18?e="下午":e="晚上",e};export{t as g};
